Vue.component('pane', {
  name:'pane',
  template: `
  <div class="pane" v-show="show">
    <slot></slot>
  </div>
  `,
  props:{
    name:{
      type:String
    },
    label:{
      type:String,
      default:''
    },
    icon: {
      type: String
    },
    disabled: {
      type: Boolean,
      default: false
    },
    closable: {
      type: Boolean,
      default: true
    }
  },
  data: function () {
    return {
      show: true
    }
  },
  computed:{
    isClosable () {
      return this.closable ? this.$parent.closable : false
    }
  },
  methods:{
    updateNav(){
      this.$parent.updateNav();
    }
  },
  watch:{
    label(){
      this.updateNav();
    }
  },
  mounted(){
    this.updateNav();
  }
});