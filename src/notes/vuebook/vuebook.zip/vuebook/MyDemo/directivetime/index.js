let app = new Vue({
  el: '#app',
  data: {
    timeNow: (new Date()).getTime(),
    timeBefore: 1499930695721,
    timeSet:  (new Date('2019/05/28')).getTime(),
  }
});
//1499930695721 2017-03-08