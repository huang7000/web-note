export default [
  {
    id: 1,
    name: 'AirPods',
    brand: 'Apple',
    image: 'https://img11.360buyimg.com/n5/s54x54_jfs/t1/29861/36/11965/55492/5c9352f7E5302d7a8/dd359563dc751ca5.jpg',
    sales: 10000,
    cost: 1288,
    color: '白色'
  },
  {
    id: 2,
    name: 'BeatsX 入耳式耳机',
    brand: 'Beats',
    image: 'https://img14.360buyimg.com/n5/s54x54_jfs/t24838/168/1872154583/290733/4f67e684/5bbf2be6N7267be92.jpg',
    sales: 11000,
    cost: 1188,
    color: '白色'
  },
  {
    id: 3,
    name: 'Beats Solo3 Wireless 头戴式式耳机',
    brand: 'Beats',
    image: 'https://img12.360buyimg.com/n5/s54x54_jfs/t1/40590/39/6406/219364/5d00d42fEb67f1e7e/9c5ea59cf4d12197.jpg',
    sales: 5000,
    cost: 2288,
    color: '金色'
  },
  {
    id: 4,
    name: 'Beats Pill+ 便携式扬声器',
    brand: 'Beats',
    image: 'https://img12.360buyimg.com/n5/s75x75_jfs/t20086/272/2227603481/176681/24c58f53/5b35ce3dN5071574d.jpg',
    sales: 3000,
    cost: 1888,
    color: '红色'
  },
  {
    id: 5,
    name: 'Sonos PLAY:1 无线扬声器',
    brand: 'Sonos',
    image: 'https://img10.360buyimg.com/n5/s75x75_jfs/t11245/55/2661576070/111257/51ceeae8/5a1b81bdNf658f926.jpg',
    sales: 8000,
    cost: 1578,
    color: '白色'
  },
  {
    id: 6,
    name: 'Powerbeats3 by Dr. Dre Wireless 入耳式耳机',
    brand: 'Beats',
    image: 'https://img10.360buyimg.com/n5/s54x54_jfs/t3226/355/3012970977/89319/a5a67942/57ea2bfaNaea9dc19.jpg',
    sales: 12000,
    cost: 1488,
    color: '白色'
  },
  {
    id: 7,
    name: 'Beats EP 头戴式耳机',
    brand: 'Beats',
    image: 'https://img11.360buyimg.com/n5/s54x54_jfs/t3055/97/1655320713/173816/94f1e229/57d12775N7a45abe5.jpg',
    sales: 25000,
    cost: 788,
    color: '蓝色'
  },
  {
    id: 8,
    name: 'B&O PLAY BeoPlay A1 便携式蓝牙扬声器',
    brand: 'B&O',
    image: 'https://img14.360buyimg.com/n5/s54x54_jfs/t18466/135/1068658617/504693/62e63680/5abb01b8Ndd984aae.jpg',
    sales: 15000,
    cost: 1898,
    color: '金色'
  },
  {
    id: 9,
    name: 'Bose® QuietComfort® 35 无线耳机',
    brand: 'Bose',
    image: 'https://img10.360buyimg.com/n5/s54x54_jfs/t1/43281/7/4238/164780/5cd22dd0E2540ca51/f1ae4f72cc5c5832.jpg',
    sales: 14000,
    cost: 2878,
    color: '金色'
  },
  {
    id: 10,
    name: 'B&O PLAY Beoplay H4 无线头戴式耳机',
    brand: 'B&O',
    image: 'https://img14.360buyimg.com/n5/s54x54_jfs/t17398/363/1063039454/173987/a38abb6b/5abb0424N55f1d5b2.jpg',
    sales: 9000,
    cost: 2298,
    color: '金色'
  }
]