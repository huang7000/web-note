let app = new Vue({
  el: '#app',
  data: {
    timeNow: (new Date('2019/06/25')).getTime(),
    timeBefore:  (new Date('2019/05/25')).getTime(),
    timeSet:  (new Date('2017/05/25')).getTime(),
  }
});
//1499930695721 2017-03-08