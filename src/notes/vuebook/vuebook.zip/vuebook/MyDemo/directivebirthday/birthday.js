let Birthday = {
  //获取当前时间戳
  getCurrentUnix: function () {
    let date = new Date();
    return date.getTime();
  },
  //转换时间
  getFormatTime: function (spanTime) {
    let spanNow = this.getCurrentUnix();//当前时间戳
    let timer = (spanNow - spanTime) / 1000;
    let tip = '';
    let year =Math.floor(timer/(365*24*60*60));
    let month=Math.floor((timer-year*365*24*60*60)/(30*24*60*60));
    let day=Math.ceil((timer-year*365*24*60*60-month*30*24*60*60)/(24*60*60));
    console.log(year+'年'+month+'月'+day+'天');
    if(year>0){
      tip=year+'年'+month+'月'+day+'天';
    }  else if (year<=0&&month>0) {
      tip=month+'月'+day+'天';
    } else {
      tip=day+'天';
    } 

    return tip;

  },
};
Vue.directive('birthday', {
  bind: function (el, binding) {
    //console.log(binding.value);
    el.innerHTML = Birthday.getFormatTime(binding.value);
    el._timeout_ = setInterval(function () {
      el.innerHTML = Birthday.getFormatTime(binding.value);
    }, 60000);
  },
  unbind: function (el) {
    //console.log('解除time指令');
    clearInterval(el._timeout_);
    delete el._timeout_;
  }
});