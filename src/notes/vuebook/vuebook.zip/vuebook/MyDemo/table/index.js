let app = new Vue({
  el: '#app',
  data: {
    columns: [
      {
        title: '姓名',
        key: 'name',
        sortable: true
      },
      {
        title: '年龄',
        key: 'age',
        sortable: true
      },
      {
        title: '出生日期',
        key: 'birthday',
        sortable: true
      }
      ,
      {
        title: '地址',
        key: 'address',
        sortable: false
      },
      ,
      {
        title: '拼音',
        key: 'pinyin',
        sortable: true
      }


    ],
    data: [
      {
        name: '王小明',
        age: 28,
        birthday: '1991-02-21',
        address: '福建省厦门市湖里',
        pinyin:'wangxiaoming'
      },
      {
        name: '陈小星',
        age: 24,
        birthday: '1995-05-21',
        address: '湖北省武汉市黄冈',
        pinyin:'chenxiaoxing'
      },
      {
        name: '赵小迪',
        age: 25,
        birthday: '1994-03-21',
        address: '福建省漳州市漳浦',
        pinyin:'zhaoxiaodi'
      },
      {
        name: '刘小军',
        age: 28,
        birthday: '1991-02-11',
        address: '福建省厦门市思明',
        pinyin:'liuxiaojun'
      },
      {
        name: '王小丫',
        age: 26,
        birthday: '1993-02-21',
        address: '福建省龙岩市武平',
        pinyin:'wangxiaoya'
      },
      {
        name: '李小红',
        age: 25,
        birthday: '1994-08-21',
        address: '福建省龙岩市武平',
        pinyin:'lixiaohong'
      },
  

    ]
  },
  methods:{
    handleAddData:function(){
      this.data.push({
        name: '黄小伟',
        age: 25,
        birthday: '1998-08-21',
        address: '福建省龙岩市武平'
      })
    }
  }

});