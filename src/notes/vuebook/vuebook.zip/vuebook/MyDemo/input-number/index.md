# number 数字框

## 基础用法

:::snippet `xh-input-number` 初始化，默认宽度百分百。

```html
<template>
  <div class="xh-demo--number">
    <xh-input-number placeholder="请输入内容" v-model="value" max="10" min="0" step="2" ></xh-input-number>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        value: ""
      };
    }
  };
</script>
<style>
  .xh-demo--input-number .xh-input-number  {
    width: 250px;
  }
</style>
```

:::

