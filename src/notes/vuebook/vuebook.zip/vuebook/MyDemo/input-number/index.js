import XhInputNumber from "./input-number.vue";

XhInputNumber.install = function (Vue) {
  Vue.component(XhInputNumber.name, XhInputNumber);
}

export default XhInputNumber;